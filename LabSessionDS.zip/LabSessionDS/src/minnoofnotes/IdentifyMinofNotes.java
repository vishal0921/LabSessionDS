package minnoofnotes;

import java.util.Scanner;

public class IdentifyMinofNotes {
	
	public static int  size ;
	public static int array [];
	public static int arraydecreasing[];
	public static int amounttopay;
	public static int sumofdenomination;
	public static int sum;
	public static int count=0;
	public static int count2=0;
	public static void main(String args[]) {
		
		MergeSortImplementation mergesortimplementation = new MergeSortImplementation();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of currency denominations");
		size = sc.nextInt();
		
		array = new int[size];
		System.out.println("Enter the currency denominations value");
		for (int i=0;i<array.length; i++) {
			array[i]=sc.nextInt();
		}
		
		System.out.println("Enter the amount you want to pay");
		amounttopay = sc.nextInt();
		
		System.out.println("Your payment approach in order to give min no of notes will be");
		mergesortimplementation.sortArray(array,0,array.length-1);
		int j=0;
		arraydecreasing = new int[size];
		for(int i= array.length;i>0;i--) {
			
			arraydecreasing[j]=array[i-1];
			j++;			
		}
		identifyminofnotes(arraydecreasing,amounttopay);		
		sc.close();
	}
	
	public static  void identifyminofnotes(int notes[], int amount) {
		int[] notescounter = new int[notes.length];
		
		try {
			for(int i=0; i<notes.length;i++) {
				if(amount>=notes[i]) {
					notescounter[i] = amount/notes[i];
					amount = amount - notescounter[i]*notes[i];
				}
			}
			if(amount>0) {
				System.out.println("exact amount cannot be given with the highest denomination");
				
			}else {
				System.out.println("your payment approach in order to give min no of notes will be");
				for(int i=0;i<notes.length;i++) {
					if(notescounter[i]!=0) {
						System.out.println(notes[i]+ ":" +notescounter[i]);
					}
				}
			}
		}catch (ArithmeticException e){
			System.out.println(e+"notes of denomination 0 is invalid");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
