package lab.session.paymoney.model;

public class Transaction {
	public int sizeoftransactionarray;
	int [] transactionarray;
	int nooftargets;
	int target;
	
	
	public int getSizeoftransactionarray() {
		return sizeoftransactionarray;
	}
	public void setSizeoftransactionarray(int sizeoftransactionarray) {
		this.sizeoftransactionarray = sizeoftransactionarray;
	}
	public int[] getTransactionarray() {
		return transactionarray;
	}
	public void setTransactionarray(int[] transactionarray) {
		this.transactionarray = transactionarray;
	}
	public int getNooftargets() {
		return nooftargets;
	}
	public void setNooftargets(int nooftargets) {
		this.nooftargets = nooftargets;
	}
	public int getTarget() {
		return target;
	}
	public void setTarget(int target) {
		this.target = target;
	}
	
	

}
