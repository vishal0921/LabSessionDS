package lab.session.paymoney.services;

import java.util.Scanner;

public class TransactionServices {
	
	public int sizeoftransactionarray;
	int [] transactionarray;
	int nooftargets;
	long target;
	int sumoftransaction;
	boolean status;
	Scanner sc = new Scanner(System.in);
	
	
	public void inputtransactionarray() {
		System.out.println("Enter the size of transaction array");
		
		sizeoftransactionarray = sc.nextInt();
		transactionarray = new int[sizeoftransactionarray]; // Array initialization 
		System.out.println("Enter the values of array");
		insertValues();
		System.out.println("Enter the total no of targets that needs to be achieved");
		nooftargets = sc.nextInt();
	}
	
	public void insertValues() {
		// Your code here...
		for (int i = 0; i < sizeoftransactionarray; i++) {
			transactionarray[i] = sc.nextInt();
		}
	}
	
	public void determintargetachieved() {
			
		
		while(nooftargets -- != 0) {
			System.out.println("Enter the value of target");
			target = sc.nextInt();	
			for (int j = 0; j < transactionarray.length; j++) {
				sumoftransaction += sumoftransaction+transactionarray[j];
				if (sumoftransaction>= target) {
					System.out.println("Target achieved after "+(j+1)+" transactions");
					status=true;
					break;					
				} 
			}
			
		}
		if(status = false) {
			System.out.println("Element not found ");
		}
	}

}
