package lab.session.paymoney.driver;

import lab.session.paymoney.services.TransactionServices;

public class Mainpaymoney {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TransactionServices transactionservices = new TransactionServices();
		transactionservices.inputtransactionarray();
		transactionservices.determintargetachieved();
	}

}
